package logneg;
import dao.*;
import modelo.*;
import java.util.*;
import javax.ejb.*;
@Stateless
@LocalBean
public class MMensaje {
    @EJB private MensajeFacade dao;
    @EJB private ConversacionFacade daoConversacion;
    @EJB private UsuarioFacade daoUsuario;
    public List<Mensaje> consultar() { return dao.findAll(); }
    public List<Conversacion> consultarConversacion() { return daoConversacion.findAll(); }
    public List<Usuario> consultarUsuario() { return daoUsuario.findAll(); }
    public void guardar(Mensaje dato, Integer idConversacion, Integer idUsuario) {
        if (dato.getContenido() == null || dato.getContenido().trim().isEmpty()) throw new IllegalArgumentException("Mensaje es obligatorio.");
        Conversacion refidConversacion = idConversacion == null ? null : daoConversacion.find(idConversacion);
        if (refidConversacion == null) throw new IllegalArgumentException("Selecciona un registro existente para conversación.");
        dato.setIdConversacion(refidConversacion);
        Usuario refidUsuario = idUsuario == null ? null : daoUsuario.find(idUsuario);
        if (refidUsuario == null) throw new IllegalArgumentException("Selecciona un registro existente para remitente.");
        dato.setIdUsuario(refidUsuario);
        Conversacion c = dato.getIdConversacion();
        if (!dato.getIdUsuario().equals(c.getIdUsuario1()) && !dato.getIdUsuario().equals(c.getIdUsuario2())) throw new IllegalArgumentException("El remitente debe participar en la conversación.");
        if (dato.getIdMensaje() == null) { dato.setFechaHoraEnvio(new Date()); dato.setLeido(false); }
        c.setFechaUltimActividad(new Date());
        daoConversacion.edit(c);
        if (dato.getIdMensaje() == null) dao.create(dato);
        else { if (dao.find(dato.getIdMensaje()) == null) throw new IllegalArgumentException("El registro ya no existe."); dao.edit(dato); }
    }
    public void eliminar(Integer id) {
        Mensaje existente = id == null ? null : dao.find(id);
        if (existente == null) throw new IllegalArgumentException("El registro ya no existe.");
        dao.remove(existente);
    }
}
